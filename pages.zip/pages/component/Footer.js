import React from 'react'

const Footer = () => {
    return (
        <div className='h-28 flex justify-center items-center bg-gray-200 text-2xl'>
            All right are reserved. &copy; 2024
        </div>
    )
}

export default Footer