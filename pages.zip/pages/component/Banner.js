'use client'

import Link from "next/link"
import { useState } from "react"

function Banner() {
    const [city, setCity] = useState("")

    return (
        <div className='bg-gradient-to-r from-red-600 to-red-400 h-60'>
            <div className='p-5'>
                <h2 className='text-4xl font-bold text-white text-center'>Over 157,000 hotels and homes across 35 countries</h2>
                <div className='flex justify-center my-5 mx-20'>
                    <input type="text" placeholder='Search.....' className=' h-16 outline-none px-3 text-lg border-r-2 border-gray-400 w-6/12' onChange={(e) => setCity(e.target.value)} />
                    {/* <input type="text" placeholder='Search.....' className=' h-16 outline-none px-3 text-lg border-r-2 border-gray-400 col-span-1' />
                    <input type="text" placeholder='Search.....' className=' h-16 outline-none px-3 text-lg border-r-2 border-gray-400 col-span-1' /> */}
                    <Link href={`/hotels?city=${city}`}>
                        <button type="submit" className='h-16 px-3 py-2 w-72 bg-green-400 hover:cursor-pointer hover:bg-green-600 text-white w-60'>Search</button>
                    </Link>

                </div>

                <div className='flex mx-20 my-5 font-bold'>
                    <button type="submit" className='h-16 px-3 py-2  hover:cursor-pointer  text-white text-xl mr-5'>Continue your search</button>
                    <button type="submit" className='h-16 px-3 py-2  hover:cursor-pointer border-2 border-white text-white hover:bg-gray-500 mr-5 rounded-xl'>Homestay in India hotels</button>
                </div></div>
        </div>
    )
}

export default Banner