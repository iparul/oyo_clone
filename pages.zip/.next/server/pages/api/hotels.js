"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/hotels";
exports.ids = ["pages/api/hotels"];
exports.modules = {

/***/ "bcrypt":
/*!*************************!*\
  !*** external "bcrypt" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fhotels&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Chotels%5Cindex.js&middlewareConfigBase64=e30%3D!":
/*!**************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fhotels&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Chotels%5Cindex.js&middlewareConfigBase64=e30%3D! ***!
  \**************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_hotels_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages\\api\\hotels\\index.js */ \"(api)/./pages/api/hotels/index.js\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_hotels_index_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_hotels_index_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/hotels\",\n        pathname: \"/api/hotels\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_hotels_index_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRmhvdGVscyZwcmVmZXJyZWRSZWdpb249JmFic29sdXRlUGFnZVBhdGg9LiUyRnBhZ2VzJTVDYXBpJTVDaG90ZWxzJTVDaW5kZXguanMmbWlkZGxld2FyZUNvbmZpZ0Jhc2U2ND1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ0w7QUFDMUQ7QUFDMkQ7QUFDM0Q7QUFDQSxpRUFBZSx3RUFBSyxDQUFDLHVEQUFRLFlBQVksRUFBQztBQUMxQztBQUNPLGVBQWUsd0VBQUssQ0FBQyx1REFBUTtBQUNwQztBQUNPLHdCQUF3QixnSEFBbUI7QUFDbEQ7QUFDQSxjQUFjLHlFQUFTO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0wsWUFBWTtBQUNaLENBQUM7O0FBRUQiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9veW8tY2xvbmUvP2Q0ODgiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGFnZXNBUElSb3V0ZU1vZHVsZSB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1tb2R1bGVzL3BhZ2VzLWFwaS9tb2R1bGUuY29tcGlsZWRcIjtcbmltcG9ydCB7IFJvdXRlS2luZCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2Z1dHVyZS9yb3V0ZS1raW5kXCI7XG5pbXBvcnQgeyBob2lzdCB9IGZyb20gXCJuZXh0L2Rpc3QvYnVpbGQvdGVtcGxhdGVzL2hlbHBlcnNcIjtcbi8vIEltcG9ydCB0aGUgdXNlcmxhbmQgY29kZS5cbmltcG9ydCAqIGFzIHVzZXJsYW5kIGZyb20gXCIuL3BhZ2VzXFxcXGFwaVxcXFxob3RlbHNcXFxcaW5kZXguanNcIjtcbi8vIFJlLWV4cG9ydCB0aGUgaGFuZGxlciAoc2hvdWxkIGJlIHRoZSBkZWZhdWx0IGV4cG9ydCkuXG5leHBvcnQgZGVmYXVsdCBob2lzdCh1c2VybGFuZCwgXCJkZWZhdWx0XCIpO1xuLy8gUmUtZXhwb3J0IGNvbmZpZy5cbmV4cG9ydCBjb25zdCBjb25maWcgPSBob2lzdCh1c2VybGFuZCwgXCJjb25maWdcIik7XG4vLyBDcmVhdGUgYW5kIGV4cG9ydCB0aGUgcm91dGUgbW9kdWxlIHRoYXQgd2lsbCBiZSBjb25zdW1lZC5cbmV4cG9ydCBjb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBQYWdlc0FQSVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5QQUdFU19BUEksXG4gICAgICAgIHBhZ2U6IFwiL2FwaS9ob3RlbHNcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9ob3RlbHNcIixcbiAgICAgICAgLy8gVGhlIGZvbGxvd2luZyBhcmVuJ3QgdXNlZCBpbiBwcm9kdWN0aW9uLlxuICAgICAgICBidW5kbGVQYXRoOiBcIlwiLFxuICAgICAgICBmaWxlbmFtZTogXCJcIlxuICAgIH0sXG4gICAgdXNlcmxhbmRcbn0pO1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1wYWdlcy1hcGkuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fhotels&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Chotels%5Cindex.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./db.js":
/*!***************!*\
  !*** ./db.js ***!
  \***************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst URL = process.env.MONGO_URI;\nconst connectDB = async ()=>{\n    await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(URL, {\n        useNewUrlParser: true,\n        useUnifiedTopology: true\n    });\n    console.log(\"DB connect  .....\");\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (connectDB);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9kYi5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBK0I7QUFFL0IsTUFBTUMsTUFBTUMsUUFBUUMsR0FBRyxDQUFDQyxTQUFTO0FBQ2pDLE1BQU1DLFlBQVk7SUFDZCxNQUFNTCx1REFBZ0IsQ0FBQ0MsS0FBSztRQUN4Qk0saUJBQWlCO1FBQ2pCQyxvQkFBb0I7SUFDeEI7SUFDQUMsUUFBUUMsR0FBRyxDQUFDO0FBQ2hCO0FBRUEsaUVBQWVMLFNBQVNBLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9veW8tY2xvbmUvLi9kYi5qcz81NjY1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBtb25nb29zZSBmcm9tIFwibW9uZ29vc2VcIlxyXG5cclxuY29uc3QgVVJMID0gcHJvY2Vzcy5lbnYuTU9OR09fVVJJXHJcbmNvbnN0IGNvbm5lY3REQiA9IGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoVVJMLCB7XHJcbiAgICAgICAgdXNlTmV3VXJsUGFyc2VyOiB0cnVlLFxyXG4gICAgICAgIHVzZVVuaWZpZWRUb3BvbG9neTogdHJ1ZVxyXG4gICAgfSlcclxuICAgIGNvbnNvbGUubG9nKFwiREIgY29ubmVjdCAgLi4uLi5cIilcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY29ubmVjdERCIl0sIm5hbWVzIjpbIm1vbmdvb3NlIiwiVVJMIiwicHJvY2VzcyIsImVudiIsIk1PTkdPX1VSSSIsImNvbm5lY3REQiIsImNvbm5lY3QiLCJ1c2VOZXdVcmxQYXJzZXIiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJjb25zb2xlIiwibG9nIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./db.js\n");

/***/ }),

/***/ "(api)/./models/hotel-model.js":
/*!*******************************!*\
  !*** ./models/hotel-model.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst hotelSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    name: {\n        type: String,\n        required: true,\n        trime: true,\n        unique: true\n    },\n    description: {\n        type: String,\n        required: true,\n        trime: true\n    },\n    banner: {\n        type: String,\n        required: true\n    },\n    gallery: [\n        {\n            type: String\n        }\n    ],\n    price: {\n        type: Number\n    },\n    facilities: [\n        {\n            img: String,\n            name: String\n        }\n    ],\n    location: {\n        type: String,\n        required: true\n    }\n}, {\n    timestamps: true\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((mongoose__WEBPACK_IMPORTED_MODULE_0___default().models)?.hotel || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"hotel\", hotelSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvaG90ZWwtbW9kZWwuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWdDO0FBRWhDLE1BQU1DLGNBQWMsSUFBSUQsd0RBQWUsQ0FBQztJQUNwQ0csTUFBTTtRQUNGQyxNQUFNQztRQUNOQyxVQUFVO1FBQ1ZDLE9BQU87UUFDUEMsUUFBUTtJQUNaO0lBQ0FDLGFBQWE7UUFDVEwsTUFBTUM7UUFDTkMsVUFBVTtRQUNWQyxPQUFPO0lBQ1g7SUFDQUcsUUFBUTtRQUNKTixNQUFNQztRQUNOQyxVQUFVO0lBQ2Q7SUFDQUssU0FBUztRQUNMO1lBQ0lQLE1BQU1DO1FBQ1Y7S0FDSDtJQUNETyxPQUFPO1FBQUVSLE1BQU1TO0lBQU87SUFDdEJDLFlBQVk7UUFDUjtZQUNJQyxLQUFLVjtZQUNMRixNQUFNRTtRQUNWO0tBQ0g7SUFDRFcsVUFBVTtRQUNOWixNQUFNQztRQUNOQyxVQUFVO0lBQ2Q7QUFDSixHQUFHO0lBQUVXLFlBQVk7QUFBSztBQUV0QixpRUFBZWpCLHdEQUFlLEVBQUVtQixTQUFTbkIscURBQWMsQ0FBQyxTQUFTQyxZQUFZQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vb3lvLWNsb25lLy4vbW9kZWxzL2hvdGVsLW1vZGVsLmpzP2Y4MDIiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IG1vbmdvb3NlIGZyb20gXCJtb25nb29zZVwiO1xyXG5cclxuY29uc3QgaG90ZWxTY2hlbWEgPSBuZXcgbW9uZ29vc2UuU2NoZW1hKHtcclxuICAgIG5hbWU6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgdHJpbWU6IHRydWUsXHJcbiAgICAgICAgdW5pcXVlOiB0cnVlXHJcbiAgICB9LFxyXG4gICAgZGVzY3JpcHRpb246IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICAgICAgdHJpbWU6IHRydWVcclxuICAgIH0sXHJcbiAgICBiYW5uZXI6IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICB9LFxyXG4gICAgZ2FsbGVyeTogW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgdHlwZTogU3RyaW5nLFxyXG4gICAgICAgIH1cclxuICAgIF0sXHJcbiAgICBwcmljZTogeyB0eXBlOiBOdW1iZXIgfSxcclxuICAgIGZhY2lsaXRpZXM6IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGltZzogU3RyaW5nLFxyXG4gICAgICAgICAgICBuYW1lOiBTdHJpbmdcclxuICAgICAgICB9XHJcbiAgICBdLFxyXG4gICAgbG9jYXRpb246IHtcclxuICAgICAgICB0eXBlOiBTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6IHRydWUsXHJcbiAgICB9XHJcbn0sIHsgdGltZXN0YW1wczogdHJ1ZSB9KVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgbW9uZ29vc2UubW9kZWxzPy5ob3RlbCB8fCBtb25nb29zZS5tb2RlbCgnaG90ZWwnLCBob3RlbFNjaGVtYSkiXSwibmFtZXMiOlsibW9uZ29vc2UiLCJob3RlbFNjaGVtYSIsIlNjaGVtYSIsIm5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJ0cmltZSIsInVuaXF1ZSIsImRlc2NyaXB0aW9uIiwiYmFubmVyIiwiZ2FsbGVyeSIsInByaWNlIiwiTnVtYmVyIiwiZmFjaWxpdGllcyIsImltZyIsImxvY2F0aW9uIiwidGltZXN0YW1wcyIsIm1vZGVscyIsImhvdGVsIiwibW9kZWwiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./models/hotel-model.js\n");

/***/ }),

/***/ "(api)/./pages/api/hotels/index.js":
/*!***********************************!*\
  !*** ./pages/api/hotels/index.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/db */ \"(api)/./db.js\");\n/* harmony import */ var _models_hotel_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/models/hotel-model */ \"(api)/./models/hotel-model.js\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! bcrypt */ \"bcrypt\");\n/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\n/* harmony import */ var jsonwebtoken__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(jsonwebtoken__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nasync function handler(req, res) {\n    if (req.method == \"POST\") {\n        (0,_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"])();\n        const newHotel = new _models_hotel_model__WEBPACK_IMPORTED_MODULE_1__[\"default\"](req.body);\n        const result = await newHotel.save();\n        res.status(200).json({\n            msg: \"Hotel Added!\",\n            result\n        });\n    }\n    if (req.method == \"GET\") {\n        (0,_db__WEBPACK_IMPORTED_MODULE_0__[\"default\"])();\n        const location = req.query.city;\n        const hotelList = await _models_hotel_model__WEBPACK_IMPORTED_MODULE_1__[\"default\"].find({\n            location\n        });\n        if (hotelList.length > 0) {\n            res.status(200).json({\n                hotelList: hotelList\n            });\n        }\n        const allHotelList = await _models_hotel_model__WEBPACK_IMPORTED_MODULE_1__[\"default\"].find({});\n        res.status(200).json({\n            hotelList: allHotelList\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvaG90ZWxzL2luZGV4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBNkI7QUFDWTtBQUNiO0FBQ0c7QUFFaEIsZUFBZUksUUFBUUMsR0FBRyxFQUFFQyxHQUFHO0lBQzFDLElBQUlELElBQUlFLE1BQU0sSUFBSSxRQUFRO1FBQ3RCUCwrQ0FBU0E7UUFDVCxNQUFNUSxXQUFXLElBQUlQLDJEQUFLQSxDQUFDSSxJQUFJSSxJQUFJO1FBQ25DLE1BQU1DLFNBQVMsTUFBTUYsU0FBU0csSUFBSTtRQUNsQ0wsSUFBSU0sTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztZQUNqQkMsS0FBSztZQUFnQko7UUFDekI7SUFDSjtJQUNBLElBQUlMLElBQUlFLE1BQU0sSUFBSSxPQUFPO1FBQ3JCUCwrQ0FBU0E7UUFDVCxNQUFNZSxXQUFXVixJQUFJVyxLQUFLLENBQUNDLElBQUk7UUFDL0IsTUFBTUMsWUFBWSxNQUFNakIsZ0VBQVUsQ0FBQztZQUFFYztRQUFTO1FBQzlDLElBQUlHLFVBQVVFLE1BQU0sR0FBRyxHQUFHO1lBQ3RCZCxJQUFJTSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUNqQkssV0FBV0E7WUFDZjtRQUNKO1FBQ0EsTUFBTUcsZUFBZSxNQUFNcEIsZ0VBQVUsQ0FBQyxDQUFDO1FBQ3ZDSyxJQUFJTSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO1lBQ2pCSyxXQUFXRztRQUNmO0lBQ0o7QUFDSiIsInNvdXJjZXMiOlsid2VicGFjazovL295by1jbG9uZS8uL3BhZ2VzL2FwaS9ob3RlbHMvaW5kZXguanM/ZDdlMSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgY29ubmVjdERCIGZyb20gXCJAL2RiXCI7XHJcbmltcG9ydCBIb3RlbCBmcm9tIFwiQC9tb2RlbHMvaG90ZWwtbW9kZWxcIjtcclxuaW1wb3J0IGJjcnlwdCBmcm9tIFwiYmNyeXB0XCI7XHJcbmltcG9ydCBqd3QgZnJvbSBcImpzb253ZWJ0b2tlblwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xyXG4gICAgaWYgKHJlcS5tZXRob2QgPT0gXCJQT1NUXCIpIHtcclxuICAgICAgICBjb25uZWN0REIoKTtcclxuICAgICAgICBjb25zdCBuZXdIb3RlbCA9IG5ldyBIb3RlbChyZXEuYm9keSlcclxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBuZXdIb3RlbC5zYXZlKClcclxuICAgICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7XHJcbiAgICAgICAgICAgIG1zZzogXCJIb3RlbCBBZGRlZCFcIiwgcmVzdWx0XHJcbiAgICAgICAgfSlcclxuICAgIH1cclxuICAgIGlmIChyZXEubWV0aG9kID09IFwiR0VUXCIpIHtcclxuICAgICAgICBjb25uZWN0REIoKTtcclxuICAgICAgICBjb25zdCBsb2NhdGlvbiA9IHJlcS5xdWVyeS5jaXR5XHJcbiAgICAgICAgY29uc3QgaG90ZWxMaXN0ID0gYXdhaXQgSG90ZWwuZmluZCh7IGxvY2F0aW9uIH0pXHJcbiAgICAgICAgaWYgKGhvdGVsTGlzdC5sZW5ndGggPiAwKSB7XHJcbiAgICAgICAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHtcclxuICAgICAgICAgICAgICAgIGhvdGVsTGlzdDogaG90ZWxMaXN0XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IGFsbEhvdGVsTGlzdCA9IGF3YWl0IEhvdGVsLmZpbmQoe30pXHJcbiAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oe1xyXG4gICAgICAgICAgICBob3RlbExpc3Q6IGFsbEhvdGVsTGlzdFxyXG4gICAgICAgIH0pXHJcbiAgICB9XHJcbn0iXSwibmFtZXMiOlsiY29ubmVjdERCIiwiSG90ZWwiLCJiY3J5cHQiLCJqd3QiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwibWV0aG9kIiwibmV3SG90ZWwiLCJib2R5IiwicmVzdWx0Iiwic2F2ZSIsInN0YXR1cyIsImpzb24iLCJtc2ciLCJsb2NhdGlvbiIsInF1ZXJ5IiwiY2l0eSIsImhvdGVsTGlzdCIsImZpbmQiLCJsZW5ndGgiLCJhbGxIb3RlbExpc3QiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/hotels/index.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Fhotels&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Chotels%5Cindex.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();